#!/usr/bin/env python3
"""PPT統一デザイン調整（中身は変えない）。
使い方: python3 pptx_normalize.py in.pptx style.json out.pptx log.xlsx [--dry-run]
調整: 文字サイズの段階統一／図形のグリッド吸着・端揃え・サイズ統一／インデント／余白(inset)／タイトル位置。
テキスト・ノート・図形の数と順序は変更しない。実行後に中身一致を自動検証する。"""
import sys, json, re, hashlib, copy, statistics
from pptx import Presentation
from pptx.util import Pt, Emu
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill

IN = 914400.0
def i2e(v): return int(round(v * IN))
def e2i(v): return v / IN

def iter_shapes(shapes):
    for s in shapes:
        yield s
        if s.shape_type == 6: yield from iter_shapes(s.shapes)

def content_fingerprint(prs):
    """中身の指紋：各スライドのテキスト(段落順)・ノート・図形数・図形種別。書式は含めない。"""
    out = []
    for i, sl in enumerate(prs.slides, 1):
        items = []
        for s in iter_shapes(sl.shapes):
            t = []
            if s.has_text_frame:
                t = [p.text for p in s.text_frame.paragraphs]
            if getattr(s, "has_table", False) and s.has_table:
                t += [c.text for r in s.table.rows for c in r.cells]
            items.append((str(s.shape_type), s.name, tuple(t)))
        notes = sl.notes_slide.notes_text_frame.text if sl.has_notes_slide else ""
        out.append((i, tuple(items), notes))
    return hashlib.sha256(repr(out).encode("utf-8")).hexdigest(), out

LOG = []
def log(slide, shape, prop, before, after):
    LOG.append([slide, shape, prop, before, after])

def is_title(sh):
    try: return sh.is_placeholder and sh.placeholder_format.type in (1, 3, 5)
    except Exception: return False
def is_footer_ph(sh):
    try: return sh.is_placeholder and sh.placeholder_format.type in (13, 15, 16)
    except Exception: return False

def snap(v, g): return int(round(v / g)) * g

def cluster(vals, tol):
    """近い値をクラスタ化し、{元値: 中央値} を返す"""
    vs = sorted(set(vals)); groups = []; cur = [vs[0]] if vs else []
    for v in vs[1:]:
        if v - cur[-1] <= tol: cur.append(v)
        else: groups.append(cur); cur = [v]
    if cur: groups.append(cur)
    m = {}
    for g in groups:
        med = statistics.median(g)
        for v in g: m[v] = med
    return m

def main(src, cfg_path, out, logp, dry=False):
    cfg = json.load(open(cfg_path, encoding="utf-8")); ap = cfg["apply"]
    prs = Presentation(src); before_fp, _ = content_fingerprint(prs)
    tiers = cfg["font_tiers_pt"]; tol = cfg["font_snap_tolerance_pt"]; ex = cfg.get("exempt_text_regex")
    g = cfg["grid_in"]; gt = cfg.get("grid_snap_tol_in", 0.02); atol = cfg["align_tolerance_in"]; stol = cfg["size_tolerance_in"]; mx = cfg["max_move_in"]
    warn = []

    # 1) タイトル基準位置（表紙等を除く中央値）
    tpos = {}
    for i, sl in enumerate(prs.slides, 1):
        if i in cfg["title"]["skip_slides"]: continue
        for sh in sl.shapes:
            if is_title(sh) and sh.left is not None: tpos[i] = (sh.left, sh.top, sh.width, sh.height)
    tstd = None
    if tpos:
        tstd = tuple(int(statistics.median([p[k] for p in tpos.values()])) for k in range(4))

    from collections import Counter
    ind = {}
    for sl in prs.slides:
        for sh in iter_shapes(sl.shapes):
            if sh.has_text_frame and not is_title(sh):
                for p in sh.text_frame.paragraphs:
                    pPr = p._p.pPr
                    if pPr is not None and pPr.get("marL") is not None and int(pPr.get("marL")) > 0:
                        ind.setdefault(p.level, Counter())[int(pPr.get("marL"))] += 1
    indent_mode = {lv: c.most_common(1)[0][0] for lv, c in ind.items()}
    midwarn = {}
    for i, sl in enumerate(prs.slides, 1):
        shapes = [s for s in iter_shapes(sl.shapes)]
        # 2) 文字サイズ（段階に吸着）
        if ap["font_size"]:
            for sh in shapes:
                if not sh.has_text_frame: continue
                if ex and re.search(ex, sh.text_frame.text.strip()): continue
                for p in sh.text_frame.paragraphs:
                    for r in p.runs:
                        if r.font.size is None: continue
                        cur = r.font.size.pt
                        ds = sorted(tiers, key=lambda t: abs(t - cur))
                        near = ds[0]
                        if len(ds) > 1 and abs(abs(ds[0] - cur) - abs(ds[1] - cur)) < 0.01 and abs(near - cur) > 0.01:
                            midwarn.setdefault(cur, []).append(i); continue
                        if abs(near - cur) <= tol and abs(near - cur) > 0.01:
                            log(i, sh.name, "文字サイズ(pt)", cur, near)
                            if not dry: r.font.size = Pt(near)
                        elif abs(near - cur) > tol:
                            midwarn.setdefault(("外", cur), []).append(i)
        # 3) インデント（デッキ内の最頻値に揃える。hanging(indent)は保持）
        if ap["indent"]:
            for sh in shapes:
                if not sh.has_text_frame or is_title(sh): continue
                for p in sh.text_frame.paragraphs:
                    pPr = p._p.pPr
                    if pPr is None or pPr.get("marL") is None: continue
                    marL = int(pPr.get("marL")); want = indent_mode.get(p.level)
                    if want is not None and marL != want and abs(marL - want) <= i2e(cfg["indent_tol_in"]):
                        log(i, sh.name, f"インデント左(in) レベル{p.level}", round(marL / IN, 3), round(want / IN, 3))
                        if not dry: pPr.set("marL", str(want))
        # 4) 余白(inset) と段落間隔
        if ap["insets"]:
            for sh in shapes:
                if not sh.has_text_frame or is_footer_ph(sh): continue
                tf = sh.text_frame
                for k, a in (("left", "margin_left"), ("right", "margin_right"), ("top", "margin_top"), ("bottom", "margin_bottom")):
                    want = i2e(cfg["insets_in"][k]); cur = getattr(tf, a)
                    if cur is not None and abs(cur - want) > 1000:
                        log(i, sh.name, f"inset {k}(in)", round(cur / IN, 2), cfg["insets_in"][k])
                        if not dry: setattr(tf, a, want)
        if ap["paragraph_spacing"]:
            pg = cfg["paragraph"]
            for sh in shapes:
                if not sh.has_text_frame or is_title(sh): continue
                for p in sh.text_frame.paragraphs:
                    if pg["line_spacing"] and p.line_spacing != pg["line_spacing"]:
                        log(i, sh.name, "行間", p.line_spacing, pg["line_spacing"])
                        if not dry: p.line_spacing = pg["line_spacing"]
                    if pg["space_after_pt"] is not None and (p.space_after is None or abs(p.space_after.pt - pg["space_after_pt"]) > 0.1):
                        log(i, sh.name, "段落後(pt)", p.space_after.pt if p.space_after else None, pg["space_after_pt"])
                        if not dry: p.space_after = Pt(pg["space_after_pt"])
        # 5) 図形の位置・サイズ（トップレベル図形のみ。グループ内は触らない）
        top = [s for s in sl.shapes if s.left is not None and s.width is not None and not is_footer_ph(s)]
        movable = [s for s in top if not is_title(s)]
        if ap["align_cluster"] and movable:
            lm = cluster([s.left for s in movable], i2e(atol)); tm = cluster([s.top for s in movable], i2e(atol))
            for s in movable:
                nl, nt = int(lm[s.left]), int(tm[s.top])
                if 0 < abs(nl - s.left) <= i2e(mx) or 0 < abs(nt - s.top) <= i2e(mx):
                    if abs(nl - s.left) <= i2e(mx) and nl != s.left:
                        log(i, s.name, "左端(in)", round(e2i(s.left), 3), round(e2i(nl), 3));  nl_ = nl
                    else: nl_ = s.left
                    if abs(nt - s.top) <= i2e(mx) and nt != s.top:
                        log(i, s.name, "上端(in)", round(e2i(s.top), 3), round(e2i(nt), 3)); nt_ = nt
                    else: nt_ = s.top
                    if not dry: s.left, s.top = nl_, nt_
        if ap["size_cluster"] and movable:
            wm = cluster([s.width for s in movable], i2e(stol)); hm = cluster([s.height for s in movable], i2e(stol))
            for s in movable:
                nw, nh = int(wm[s.width]), int(hm[s.height])
                if nw != s.width and abs(nw - s.width) <= i2e(mx):
                    log(i, s.name, "幅(in)", round(e2i(s.width), 3), round(e2i(nw), 3))
                    if not dry: s.width = nw
                if nh != s.height and abs(nh - s.height) <= i2e(mx):
                    log(i, s.name, "高さ(in)", round(e2i(s.height), 3), round(e2i(nh), 3))
                    if not dry: s.height = nh
        if ap["grid_snap"]:
            for s in movable:
                for a, nm in (("left", "左端"), ("top", "上端"), ("width", "幅"), ("height", "高さ")):
                    cur = getattr(s, a); new = i2e(snap(e2i(cur), g))
                    if new != cur and abs(new - cur) <= i2e(gt):
                        log(i, s.name, f"{nm}(in)・グリッド吸着", round(e2i(cur), 3), round(e2i(new), 3))
                        if not dry: setattr(s, a, new)
        # 6) タイトル位置統一
        if ap["title_unify"] and cfg["title"]["unify"] and tstd and i not in cfg["title"]["skip_slides"]:
            for sh in sl.shapes:
                if is_title(sh) and sh.left is not None:
                    cur = (sh.left, sh.top, sh.width, sh.height)
                    if any(abs(a - b) > 1000 for a, b in zip(cur, tstd)):
                        log(i, sh.name, "タイトル位置/サイズ(in)", [round(e2i(v), 2) for v in cur], [round(e2i(v), 2) for v in tstd])
                        if not dry: sh.left, sh.top, sh.width, sh.height = tstd

    for k, v in midwarn.items():
        if isinstance(k, tuple): warn.append(["、".join(f"S{x}" for x in sorted(set(v))), f"{len(v)}箇所", "段階外のサイズ", k[1], "自動変更しない。意図的か確認"])
        else: warn.append(["、".join(f"S{x}" for x in sorted(set(v))), f"{len(v)}箇所", "段階の中間サイズ", k, "自動変更しない。意図的か確認"])
    # 7) 検証：中身が変わっていないこと
    if not dry: prs.save(out)
    chk = Presentation(out if not dry else src); after_fp, _ = content_fingerprint(chk)
    same = (before_fp == after_fp)
    wb = Workbook(); ws = wb.active; ws.title = "サマリー"
    ws["A1"] = "統一デザイン調整ログ"; ws["A1"].font = Font(bold=True, size=14)
    for r, (k, v) in enumerate([("入力", src), ("出力", out if not dry else "(dry-run)"), ("変更件数", len(LOG)), ("要手動確認", len(warn)),
                                 ("中身の一致検証", "一致（テキスト・ノート・図形の数と順序は不変）" if same else "不一致！出力を使わない")], 3):
        ws.cell(row=r, column=1, value=k).font = Font(bold=True); ws.cell(row=r, column=2, value=v)
    ws.column_dimensions["A"].width = 18; ws.column_dimensions["B"].width = 70
    H = PatternFill("solid", fgColor="1F3A5F")
    for name, rows, head in (("変更ログ", LOG, ["スライド", "図形", "項目", "変更前", "変更後"]), ("要手動確認", warn, ["スライド", "図形", "項目", "値", "メモ"])):
        w = wb.create_sheet(name)
        for c, h in enumerate(head, 1):
            x = w.cell(row=1, column=c, value=h); x.fill = H; x.font = Font(bold=True, color="FFFFFF")
        for r in rows: w.append([str(v) if isinstance(v, (list, tuple)) else v for v in r])
        for c, wd in enumerate([9, 22, 28, 22, 22], 1): w.column_dimensions[w.cell(row=1, column=c).column_letter].width = wd
        w.freeze_panes = "A2"
    wb.save(logp)
    print(f"変更{len(LOG)}件 / 要手動確認{len(warn)}件 / 中身一致={same}")
    if not same: sys.exit(2)

if __name__ == "__main__":
    a = [x for x in sys.argv[1:] if x != "--dry-run"]
    if len(a) != 4: sys.exit(__doc__)
    main(*a, dry="--dry-run" in sys.argv)
