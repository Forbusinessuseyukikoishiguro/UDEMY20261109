#!/usr/bin/env python3
"""PPT要件・ブランド適合テスト → Excel出力。使い方: python3 pptx_review.py deck.pptx rules.json out.xlsx"""
import sys, json, re, statistics
from pptx import Presentation
from pptx.util import Emu
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

EMU_IN = 914400.0
def inch(v): return (v or 0) / EMU_IN

def iter_shapes(shapes):
    for s in shapes:
        yield s
        if s.shape_type == 6:  # group
            yield from iter_shapes(s.shapes)

def text_of(slide):
    out = []
    for s in iter_shapes(slide.shapes):
        if s.has_text_frame: out.append(s.text_frame.text)
        if getattr(s, "has_table", False) and s.has_table:
            for r in s.table.rows:
                for c in r.cells: out.append(c.text)
    return "\n".join(out)

def runs(slide):
    for s in iter_shapes(slide.shapes):
        if s.has_text_frame:
            for p in s.text_frame.paragraphs:
                for r in p.runs:
                    if r.text.strip(): yield s, r

def title_of(slide):
    for sh in slide.placeholders:
        try:
            if sh.placeholder_format.type in (1, 3, 5) and sh.has_text_frame and sh.text_frame.text.strip():
                return sh  # TITLE=1, CENTER_TITLE=3, VERTICAL_TITLE=5
        except Exception: pass
    return None

EXEMPT_PH = (13, 15, 16)  # SLIDE_NUMBER, FOOTER, DATE
def is_exempt(sh, rule):
    try:
        if sh.is_placeholder and sh.placeholder_format.type in EXEMPT_PH: return True
    except Exception: pass
    pat = rule.get("exempt_text_regex")
    if pat and sh.has_text_frame and re.search(pat, sh.text_frame.text.strip()): return True
    return False

R = []  # rows
def add(tid, kind, rid, text, slide, result, evidence, sev, fix=""):
    R.append([tid, kind, rid, text, slide, result, evidence, sev, fix])

def run_check(prs, rule, kind, n):
    c = rule["check"]; rid = rule["id"]; txt = rule["text"]; sev = rule.get("severity", "中")
    W, H = inch(prs.slide_width), inch(prs.slide_height)
    slides = list(prs.slides)
    def rec(slide_no, ok, ev, fix=""):
        nonlocal n
        n += 1
        add(f"T-{n:03d}", kind, rid, txt, slide_no, "PASS" if ok else "FAIL", ev, sev, fix)
    if c == "slide_count":
        k = len(slides); ok = rule["min"] <= k <= rule["max"]
        rec("全体", ok, f"{k}枚（基準 {rule['min']}〜{rule['max']}）", "枚数を調整")
    elif c == "has_title":
        bad = [i for i, s in enumerate(slides, 1) if title_of(s) is None]
        rec("全体", not bad, "全スライドに有り" if not bad else f"タイトル無し: {bad}", "タイトルプレースホルダーに入力")
    elif c == "has_notes":
        bad = [i for i, s in enumerate(slides, 1) if not (s.has_notes_slide and s.notes_slide.notes_text_frame.text.strip())]
        rec("全体", not bad, "全スライドに有り" if not bad else f"ノート無し: {bad}", "発表者ノートを追加")
    elif c == "text_regex_each":
        skip = set(rule.get("skip_slides", [])); pat = re.compile(rule["pattern"])
        bad = [i for i, s in enumerate(slides, 1) if i not in skip and not pat.search(text_of(s))]
        rec("全体", not bad, "全スライドに有り" if not bad else f"未表記: {bad}", "出典フッターを追加")
    elif c == "keywords_present":
        alltext = "\n".join(text_of(s) for s in slides)
        miss = [k for k in rule["keywords"] if k not in alltext]
        rec("全体", not miss, "全て有り" if not miss else f"不足: {miss}", "該当スライドを追加")
    elif c == "fonts_allowed":
        allowed = set(rule["allowed"]) | set(rule.get("monospace_ok", [])); bad = {}
        for i, s in enumerate(slides, 1):
            for sh, r in runs(s):
                f = r.font.name
                if f and f not in allowed: bad.setdefault(f, set()).add(i)
        rec("全体", not bad, "全て許可フォント（未指定=テーマ継承は対象外）" if not bad else "; ".join(f"{k}: {sorted(v)}" for k, v in bad.items()), "フォントをブランド指定へ")
    elif c == "min_font_size":
        mn = rule["min_pt"]; bad = {}
        for i, s in enumerate(slides, 1):
            for sh, r in runs(s):
                if is_exempt(sh, rule): continue
                sz = r.font.size.pt if r.font.size else None
                if sz and sz < mn: bad.setdefault(i, []).append(sz)
        for i in range(1, len(slides) + 1): pass
        rec("全体", not bad, f"全て{mn}pt以上（サイズ未指定は対象外）" if not bad else "; ".join(f"S{i}: 最小{min(v)}pt" for i, v in bad.items()), f"{mn}pt以上に")
    elif c == "margin":
        m = rule["min_inch"]; bad = []
        for i, s in enumerate(slides, 1):
            for sh in s.shapes:
                if sh.left is None or sh.width is None: continue
                if is_exempt(sh, rule): continue
                l, t, r_, b = inch(sh.left), inch(sh.top), inch(sh.left + sh.width), inch(sh.top + sh.height)
                if l < -0.01 or t < -0.01 or r_ > W + 0.01 or b > H + 0.01:
                    bad.append(f"S{i} {sh.name}: はみ出し")
                elif sh.has_text_frame and sh.text_frame.text.strip() and (l < m or t < m or r_ > W - m or b > H - m):
                    bad.append(f"S{i} {sh.name}: 余白<{m}in")
        rec("全体", not bad, "全て範囲内" if not bad else " / ".join(bad[:8]) + (f" 他{len(bad)-8}件" if len(bad) > 8 else ""), "位置・サイズを調整")
    elif c == "empty_placeholder":
        bad = []
        for i, s in enumerate(slides, 1):
            for sh in s.placeholders:
                if sh.has_text_frame and not sh.text_frame.text.strip(): bad.append(f"S{i} {sh.name}")
        rec("全体", not bad, "無し" if not bad else ", ".join(bad), "削除または入力")
    elif c == "text_colors_allowed":
        pal = {x.upper().lstrip("#") for x in rule.get("palette", [])}
        if not pal:
            n += 1; add(f"T-{n:03d}", kind, rid, txt, "全体", "要確認", "palette未設定のため判定不可", sev, "rules.jsonにpaletteを設定"); return n
        bad = set()
        for i, s in enumerate(slides, 1):
            for sh, r in runs(s):
                try:
                    if r.font.color and r.font.color.type is not None and r.font.color.rgb is not None:
                        h = str(r.font.color.rgb).upper()
                        if h not in pal: bad.add((i, h))
                except Exception: pass
        rec("全体", not bad, "全てパレット内" if not bad else ", ".join(f"S{i}:{h}" for i, h in sorted(bad)[:10]), "ブランドカラーへ")
    elif c == "title_position_consistent":
        tol = rule["tolerance_inch"]; pos = {}
        for i, s in enumerate(slides, 1):
            t = title_of(s)
            if t is not None and t.left is not None: pos[i] = (inch(t.left), inch(t.top))
        if len(pos) < 2:
            n += 1; add(f"T-{n:03d}", kind, rid, txt, "全体", "要確認", "比較対象が不足", sev); return n
        xs = [p[0] for i, p in pos.items() if i != 1]; ys = [p[1] for i, p in pos.items() if i != 1]
        mx, my = statistics.median(xs), statistics.median(ys)
        bad = [i for i, p in pos.items() if i != 1 and (abs(p[0] - mx) > tol or abs(p[1] - my) > tol)]
        rec("全体", not bad, f"基準位置({mx:.2f},{my:.2f})in、表紙除く" if not bad else f"ずれ: {bad}（基準 {mx:.2f},{my:.2f}）", "タイトル位置を揃える")
    else:
        n += 1; add(f"T-{n:03d}", kind, rid, txt, "全体", "要確認", f"未対応のcheck: {c}", sev)
    return n

def main(pptx_path, rules_path, out):
    prs = Presentation(pptx_path); rules = json.load(open(rules_path, encoding="utf-8"))
    n = 0
    for r in rules.get("requirements", []): n = run_check(prs, r, "要件", n)
    for r in rules.get("brand", []): n = run_check(prs, r, "ブランド", n)
    for m in rules.get("manual_checks", []):
        n += 1; add(f"T-{n:03d}", "目視", m["id"], m["text"], "全体", "要目視", "PDF/画像化して人が確認", "中")
    wb = Workbook(); HF = PatternFill("solid", fgColor="1F3A5F"); thin = Side(style="thin", color="BBBBBB")
    B = Border(left=thin, right=thin, top=thin, bottom=thin)
    ws = wb.active; ws.title = "サマリー"
    cnt = {k: sum(1 for r in R if r[5] == k) for k in ["PASS", "FAIL", "要確認", "要目視"]}
    judged = cnt["PASS"] + cnt["FAIL"]
    rows = [("対象", rules.get("deck", {}).get("name", pptx_path)), ("ファイル", pptx_path), ("スライド数", len(prs.slides)),
            ("テスト総数", len(R)), ("PASS", cnt["PASS"]), ("FAIL", cnt["FAIL"]), ("要確認", cnt["要確認"]), ("要目視", cnt["要目視"]),
            ("自動判定の合格率", f"{cnt['PASS']/judged:.0%}" if judged else "—"),
            ("総合判定", "不合格（FAILあり）" if cnt["FAIL"] else ("条件付き合格（要目視・要確認あり）" if cnt["要確認"] or cnt["要目視"] else "合格"))]
    ws["A1"] = "PPTレビュー テスト結果サマリー"; ws["A1"].font = Font(bold=True, size=14)
    for i, (k, v) in enumerate(rows, 3):
        ws.cell(row=i, column=1, value=k).font = Font(bold=True); ws.cell(row=i, column=2, value=v)
    ws.column_dimensions["A"].width = 22; ws.column_dimensions["B"].width = 60
    ws2 = wb.create_sheet("テスト結果")
    head = ["テストID", "区分", "ルールID", "テスト内容", "対象", "結果", "根拠（実測）", "重大度", "対処案"]
    for i, h in enumerate(head, 1):
        c = ws2.cell(row=1, column=i, value=h); c.fill = HF; c.font = Font(bold=True, color="FFFFFF"); c.border = B
    col = {"PASS": "C6EFCE", "FAIL": "FFC7CE", "要確認": "FFEB9C", "要目視": "DDEBF7"}
    for r, row in enumerate(R, 2):
        for i, v in enumerate(row, 1):
            c = ws2.cell(row=r, column=i, value=v); c.alignment = Alignment(wrap_text=True, vertical="top"); c.border = B
        ws2.cell(row=r, column=6).fill = PatternFill("solid", fgColor=col[row[5]])
    for i, w in enumerate([9, 9, 10, 40, 8, 9, 60, 8, 28], 1): ws2.column_dimensions[ws2.cell(row=1, column=i).column_letter].width = w
    ws2.freeze_panes = "A2"; ws2.auto_filter.ref = f"A1:I{len(R)+1}"
    ws3 = wb.create_sheet("スライド一覧")
    for i, h in enumerate(["No", "タイトル", "ノート有", "文字数"], 1):
        c = ws3.cell(row=1, column=i, value=h); c.fill = HF; c.font = Font(bold=True, color="FFFFFF")
    for i, s in enumerate(prs.slides, 1):
        t = title_of(s); nt = s.has_notes_slide and bool(s.notes_slide.notes_text_frame.text.strip())
        ws3.append([i, t.text_frame.text.strip() if t is not None else "(無し)", "○" if nt else "×", len(text_of(s))])
    ws3.column_dimensions["B"].width = 50
    ws4 = wb.create_sheet("ルール定義")
    for i, h in enumerate(["ルールID", "区分", "内容", "判定方法", "パラメータ", "重大度"], 1):
        c = ws4.cell(row=1, column=i, value=h); c.fill = HF; c.font = Font(bold=True, color="FFFFFF")
    for kind, key in (("要件", "requirements"), ("ブランド", "brand")):
        for r in rules.get(key, []):
            p = {k: v for k, v in r.items() if k not in ("id", "text", "check", "severity")}
            ws4.append([r["id"], kind, r["text"], r["check"], json.dumps(p, ensure_ascii=False), r.get("severity", "")])
    for m in rules.get("manual_checks", []): ws4.append([m["id"], "目視", m["text"], "人による確認", "", ""])
    ws4.column_dimensions["C"].width = 50; ws4.column_dimensions["E"].width = 40
    wb.save(out); print(json.dumps(cnt, ensure_ascii=False), "->", out)

if __name__ == "__main__":
    if len(sys.argv) != 4: sys.exit(__doc__)
    main(*sys.argv[1:])
